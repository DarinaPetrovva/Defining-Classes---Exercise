﻿using System;
using System.Linq;

namespace OldestFamilyMember
{
  public  class StartUp
    {
      

        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            Family myfamily = new Family();
            for (int i = 1; i <= n; i++)
            {
                var input = Console.ReadLine().Split().ToArray();
                Person person = new Person(int.Parse(input[1]), input[0]);
                myfamily.AddMember(person);
            }
            var oldestPerson = myfamily.GetOldestMember();
            Console.WriteLine($"{oldestPerson.Name} {oldestPerson.Age}");
        }
    }
}
