﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Person p1 = new Person();
            Console.WriteLine(p1.Name + " " + p1.Age);

            Person p2 = new Person();
            Console.WriteLine(p2.Name + " " + p2.Age);

            Person p3 = new Person();
            Console.WriteLine(p3.Name + " " + p3.Age);

        }
    }
}
