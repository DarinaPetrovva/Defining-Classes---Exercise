﻿using System;
using System.Collections.Generic;
using System.Linq;


namespace RawData
{
   public class StartUp
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            List<Car> cars = new List<Car>();
            for (int i = 0; i < n; i++)
            {
                var input = Console.ReadLine().Split();
                string model = input[0];

                int enginespeed = int.Parse(input[1]);
                int enginepower = int.Parse(input[2]);
                Engine engine = new Engine(enginespeed, enginepower);

                int cargoweight = int.Parse(input[3]);
                string cargotype = input[4];
                Cargo cargo = new Cargo(cargoweight, cargotype);

                double tire1pressure = double.Parse(input[5]);
                int tire1age = int.Parse(input[6]);
                Tire tire1 = new Tire(tire1pressure, tire1age);

                double tire2pressure = double.Parse(input[7]);
                int tire2age = int.Parse(input[8]);
                Tire tire2 = new Tire(tire2pressure, tire2age);

                double tire3pressure = double.Parse(input[9]);
                int tire3age = int.Parse(input[10]);
                Tire tire3 = new Tire(tire3pressure, tire3age);

                double tire4pressure = double.Parse(input[11]);
                int tire4age = int.Parse(input[12]);
                Tire tire4 = new Tire(tire4pressure, tire4age);


                Car car = new Car(model, engine, cargo, tire1, tire2, tire3, tire4);
                cars.Add(car);

            }
            string type = Console.ReadLine();
            foreach (var car in cars)
            {
                if (car.Cargo.CargoType == type)
                {
                    if (type == "fragile" && (car.Tire1.TirePressure < 1 || car.Tire2.TirePressure < 1|| car.Tire3.TirePressure < 1 || car.Tire4.TirePressure < 1))
                    {
                        Console.WriteLine(car);
                    }
                    if (type == "flamable" && car.Engine.EnginePower > 250)
                    {
                        Console.WriteLine(car);
                    }
                }
            }
        }
    }
}
