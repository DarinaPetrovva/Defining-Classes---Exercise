﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RawData
{
   public class Car
    {
        public string Model { get; set; }
        public Engine Engine { get; set; }
        public Cargo Cargo { get; set; }
        public Tire Tire1 { get; set; }
        public Tire Tire2 { get; set; }
        public Tire Tire3 { get; set; }
        public Tire Tire4 { get; set; }

        public Car(string model, Engine engine, Cargo cargo, Tire tire1, Tire tire2, Tire tire3, Tire tire4)
        {
            Model = model;
            Engine = engine;
            Cargo = cargo;
            Tire1 = tire1;
            Tire2 = tire2;
            Tire3 = tire3;
            Tire4 = tire4;
        }

        public override string ToString()
        {
            return $"{Model}";
        }
    }
}
